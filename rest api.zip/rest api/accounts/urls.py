from django.urls import path,include
from . import views
from rest_framework.routers import DefaultRouter
router = DefaultRouter()
router.register('signin',views.UserLoginViewSet , basename='signin')
router.register('profile',views.UserProfileViewSet , basename='profile')
router.register('change-password',views.ChangeUserPasswordViewSet , basename='change-password')

router.register('change-password-email',views.UserEmailPasswordRestViewSet , basename='change-password-change')
router.register('sensor-record',views.FetchSensorRecord , basename='sensor-record-fetch')




urlpatterns = [
    path('',include(router.urls)),
    path('registration/',views.UserRegistrationViewSet.as_view() , name='home'),
    path('reset-password/<uid>/<token>/',views.UserPasswordUpdateRestViewSet.as_view() , name='reset-password'),
    path('logout/',views.LogoutView.as_view() , name='logout'),
]