
from rest_framework import serializers

from customs_utils.senf_mail import Utils
from .models import User , SensorModel

class UserRegistrationSerializers(serializers.ModelSerializer):
    password2 = serializers.CharField(required = True , write_only=True,style={'input_type': 'password'})
    class Meta:
        model = User
        fields = ('email','first_name','contact_address','contact_number','gender','date_of_birth','password','password2')
        extra_kwargs = {'password': {'write_only': True}, }

    def validate(self, attrs):
        password1 = attrs.get('password')
        password2 = attrs.get('password2')
        if password1!=password2:
            raise serializers.ValidationError({
                'password': ('Password Invalid.')
            })
            
        return attrs
    def create(self, validated_data):
        return User.objects.create_user(**validated_data)

class UserLoginSerializers(serializers.ModelSerializer):
    email = serializers.EmailField()
    class Meta:
        model = User
        fields = ('email','password')

class UserProfileSerializers(serializers.ModelSerializer):
    class Meta:
        model = User
        # fields = ('id','email')
        fields = '__all__'
        # read_only_fields = fields

class ChangeUserPasswordSerializers(serializers.ModelSerializer):
    password2 = serializers.CharField(required = True , write_only=True,style={'input_type': 'password'})
    class Meta:
        model = User
        fields = ['password','password2']
        extra_kwargs = {'password': {'write_only': True}, }
    
    def validate(self, attrs):
        password1 = attrs.get('password')
        password2 = attrs.get('password2')
        if password1!=password2:
            raise serializers.ValidationError({
                'password': ('Password Invalid.')
            })
            
        return attrs
    
    def update(self, instance, validated_data):
        instance.password = validated_data.get('password',instance.password)
        instance.set_password(instance.password)
        instance.save()
        return instance

from django.utils.encoding import force_bytes , smart_str , DjangoUnicodeDecodeError
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode 
from django.contrib.auth.tokens import PasswordResetTokenGenerator
class UserEmailPasswordRestSerializers(serializers.Serializer):
    email = serializers.EmailField()
    class Meta:
        fields = ['email',]
    
    def validate(self, attrs):
        email = attrs.get('email')
        print(email)
        user = None
        try:
            user = User.objects.get(email=email)
            print('user id',user.id)
            uid = urlsafe_base64_encode(force_bytes(user.id))
            token = PasswordResetTokenGenerator().make_token(user)
            print('token - ',token)
            link = f'http://127.0.0.1:8000/api/reset-password/{uid}/{token}/'
            print('link-  ',link)
            print('uid--',uid)
            # send email
            data = {
                'subject':"Email verification",
                'body':f'Please click on  {link}',
                'to_email':user.email
            }
            Utils.send_mail(data)
        except User.DoesNotExist:
            raise serializers.ValidationError({
                'email': ('Given email is not registared'),
            })
        print('user email----',user)
        return super().validate(attrs)

class UserEmailUpdateSerializers(serializers.ModelSerializer):
    password2 = serializers.CharField(required = True , write_only=True,style={'input_type': 'password'})
    class Meta:
        model = User
        fields = ['password','password2']
        extra_kwargs = {'password': {'write_only': True},}
    
    def validate(self, attrs):
        try:
            password1 = attrs.get('password')
            password2 = attrs.get('password2')
            uid = self.context.get('uid')
            token = self.context.get('token')

            id = smart_str(urlsafe_base64_decode(uid))
            print('user id',id)
            user = None
            try:
                user = User.objects.get(id = id)
            except User.DoesNotExist:
                raise serializers.ValidationError({
                    'user':('Invalid User'),
                })
            if not PasswordResetTokenGenerator().check_token(user , token):
                raise serializers.ValidationError({
                    'user':('Token is not verified or expired'),
                })
            token = self.context.get('token')

            if password1!=password2 and (password1!='' and password2!=''):
                raise serializers.ValidationError({
                    'password': ('Password Invalid.')
                })
            user.set_password(password1)
            user.save()
            
            return attrs
        except DjangoUnicodeDecodeError as identifier:
            PasswordResetTokenGenerator().check_token(user , token)
            raise serializers.ValidationError({
                    'user':('Token is not verified or expired'),
                })

        


class FetchSensorRecordSerializers(serializers.ModelSerializer):
    class Meta:
        model = SensorModel
        fields = (
        'gas_one',
        'gas_two',
        'gas_three',
        'gas_four',
        'temp',
        'hum',
        'pm_two',
        'p_tem'
        )
        