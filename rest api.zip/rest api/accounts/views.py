
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import viewsets
from .renders import UserRenders

from rest_framework.permissions import IsAuthenticated
from .serializers import(
    UserRegistrationSerializers,
    UserLoginSerializers,
    UserProfileSerializers,
    ChangeUserPasswordSerializers,
    UserEmailPasswordRestSerializers,
    UserEmailUpdateSerializers,
    FetchSensorRecordSerializers,
    )
from .models import User , SensorModel

from customs_utils.custom_response import get_message
from customs_utils.custom_pagination import LargeResultsSetPagination



def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)

    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }


class UserRegistrationViewSet(APIView):
    renderer_classes = [UserRenders]
    def post(self,request):
        serializers = UserRegistrationSerializers(data = request.data)
        if serializers.is_valid(raise_exception=True):
            user=serializers.save()
            token = get_tokens_for_user(user)
            return Response({'code':201,'message':get_message(201),'token':token})
        return Response(serializers.errors)

from django.contrib.auth import authenticate , login,logout
class UserLoginViewSet(viewsets.ModelViewSet):
    serializer_class = UserLoginSerializers
    queryset = User.objects.all()
    renderer_classes = [UserRenders]

    def create(self, request, *args, **kwargs):
        serializers = self.serializer_class(data = request.data)
        if serializers.is_valid(raise_exception=True):
            email = serializers.validated_data['email']
            password = serializers.validated_data['password']
            user = None
            user = authenticate(email = email , password = password)
            if user is not None:
                login(request , user)
                token = get_tokens_for_user(user)
                return Response({'code':200,'message':get_message(200),'result':token})
            return Response({'code':204,'message':get_message(204)})
        return Response({'errors':{'non_field_errors':["Email or password InValid"]}})


class UserProfileViewSet(viewsets.ModelViewSet):
    pagination_class = LargeResultsSetPagination
    serializer_class = UserProfileSerializers
    permission_classes = [IsAuthenticated]
    queryset = User.objects.all()


    # def get_queryset(self):
    #     user_id = self.request.user.id
    #     user = self.queryset.filter(id=user_id)
    #     return user

    def list(self, request, *args, **kwargs):
        user_id = self.request.user.id
        try:
            user_obj = User.objects.get(id = user_id , is_admin=True)
        except:
            return Response({'code':501 , 'message':get_message(501)})

        user = self.queryset.all().exclude(is_admin=True)
        serialiser =self.serializer_class(user,many=True)
        return Response(serialiser.data)

class ChangeUserPasswordViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = ChangeUserPasswordSerializers
    queryset = User.objects.all()
    pagination_class = LargeResultsSetPagination

    def create(self, request, *args, **kwargs):
        user = self.request.user.id
        try:
            user_obj = User.objects.get(id = user)
        except User.DoesNotExist:
            return Response({'code':404 , 'message':get_message(404)})

        serializers = self.serializer_class(user_obj , data = request.data)
        if serializers.is_valid(raise_exception=True):
            serializers.save()
            return Response({'code':201 , 'message':get_message(201)})
        return Response(serializers.errors)
        


class UserEmailPasswordRestViewSet(viewsets.ModelViewSet):
    serializer_class = UserEmailPasswordRestSerializers
    renderer_classes = [UserRenders]

    def create(self, request, *args, **kwargs):
        serializers = self.serializer_class(data= request.data)
        if serializers.is_valid(raise_exception=True):
            return Response({'code':201 , 'message':'Please check your email and click on givrn link for activation your email'})
        else:
            return Response({'code':604 , 'message':get_message(604)})
        
    

class UserPasswordUpdateRestViewSet(APIView):
    renderer_classes = [UserRenders]
    serializer_class = UserEmailUpdateSerializers

    def post(self, request,uid,token ,  *args, **kwargs):
        serializers = self.serializer_class(data = request.data , context={'uid':uid , 'token':token})
        if serializers.is_valid(raise_exception=True):
            return Response({'code':200,'message':'password Reset Succeffully'})
            # password = serializers.validated_data['password']
        return Response(serializers.errors)


class LogoutView(APIView):
    permission_classes = (IsAuthenticated,)
    def post(self,request):
        try:
            refresh_token = request.data["refresh_token"]
            print(refresh_token)
            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response({'code':200})
        except:
            return Response({'code':400})



class FetchSensorRecord(viewsets.ModelViewSet):
    serializer_class = FetchSensorRecordSerializers
    queryset =SensorModel.objects.all()
    permission_classes = (IsAuthenticated,)
    pagination_class = LargeResultsSetPagination

    # def get_queryset(self):
    #     if self.request.user.is_admin==True:
    #         return super().get_queryset()
    def list(self, request, *args, **kwargs):
        if self.request.user.is_admin==True:
            queryset = self.filter_queryset(self.get_queryset())
            page = self.paginate_queryset(queryset)
            if page is not None:
                serializer = self.get_serializer(page, many=True)
                return self.get_paginated_response(serializer.data)

            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return Response({'code':501,'message':get_message(501)})
            