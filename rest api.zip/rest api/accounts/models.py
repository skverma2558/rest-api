from django.db import models

# Create your models here.
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser
)


class UserManager(BaseUserManager):
    def create_user(self, email, date_of_birth,first_name,contact_address,contact_number,gender, password=None,password2=None):
        """
        Creates and saves a User with the given email, date of
        birth and password.
        """
        if not email:
            raise ValueError('User must have an email address')

        user = self.model(
            email=self.normalize_email(email),
            date_of_birth=date_of_birth,
            first_name=first_name,
            contact_address=contact_address,
            contact_number=contact_number,
            gender=gender
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, date_of_birth,first_name,contact_address,contact_number,gender, password=None):
        """
        Creates and saves a superuser with the given email, date of
        birth and password.
        """
        user = self.create_user(
            email,
            date_of_birth=date_of_birth,
            first_name=first_name,
            contact_address=contact_address,
            contact_number=contact_number,
            gender=gender,
            password=password

        )
        user.is_admin = True
        user.save(using=self._db)
        return user


class User(AbstractBaseUser):
    email = models.EmailField(
        verbose_name='Email',
        max_length=255,
        unique=True,
    )
    GENDER_CHOICE = (
        ('M','Male'),
        ('F','Female'),
        ('O','Other'),
    )
    date_of_birth = models.DateField()
    first_name = models.CharField(max_length=50,null=True,blank=True)
    contact_address = models.CharField(max_length=1000,null=True,blank=True)
    contact_number = models.CharField(max_length=15)
    gender = models.CharField(max_length=1,choices=GENDER_CHOICE,default='O')

    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name','contact_address','contact_number','gender','date_of_birth']

    def __str__(self):
        return self.email

    def has_perm(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return self.is_admin

    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return True

    @property
    def is_staff(self):
        "Is the user a member of staff?"
        # Simplest possible answer: All admins are staff
        return self.is_admin

class SensorModel(models.Model):
    gas_one=models.DecimalField(max_digits=35,decimal_places=10 , null=True,blank=True)
    gas_two=models.DecimalField(max_digits=35,decimal_places=10 , null=True,blank=True)
    gas_three=models.DecimalField(max_digits=35,decimal_places=10 , null=True,blank=True)
    gas_four=models.DecimalField(max_digits=35,decimal_places=10 , null=True,blank=True)
    temp=models.DecimalField(max_digits=35,decimal_places=10 , null=True,blank=True)
    hum=models.DecimalField(max_digits=35,decimal_places=10 , null=True,blank=True)
    pm_two=models.DecimalField(max_digits=35,decimal_places=10 , null=True,blank=True)
    p_tem=models.DecimalField(max_digits=35,decimal_places=10 , null=True,blank=True)