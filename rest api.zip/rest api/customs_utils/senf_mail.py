from django.core.mail import EmailMessage
import os
from core import settings
class Utils:
    @staticmethod
    def send_mail(data):
        
        email = EmailMessage(
            subject=data['subject'],
            body=data['body'],
            from_email=settings.EMAIL_HOST_USER,
            to=[
                data['to_email']
                ]
            )

        print(email)
        email.send()